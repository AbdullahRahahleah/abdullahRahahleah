package rahahleah.rahahleah.Beans;
public class HotelUrls {
	public String getHotelInfositeUrl() {
		return hotelInfositeUrl;
	}
	public void setHotelInfositeUrl(String hotelInfositeUrl) {
		this.hotelInfositeUrl = hotelInfositeUrl;
	}
	public String getHotelSearchResultUrl() {
		return hotelSearchResultUrl;
	}
	public void setHotelSearchResultUrl(String hotelSearchResultUrl) {
		this.hotelSearchResultUrl = hotelSearchResultUrl;
	}
	private String hotelInfositeUrl;
	private String hotelSearchResultUrl;
	

}
